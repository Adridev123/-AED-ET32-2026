﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace MiPrimerJuego
{
    internal class Obstaculo
    {
        public Rectangle Area;
        public bool Activo;

        public Obstaculo(int x, int y, int ancho, int alto)
        {
            Area = new Rectangle(x, y, ancho, alto);
            Activo = true;
        }
    }

    internal class Pared
    {
        public Rectangle Area;

        public Pared(int x, int y, int ancho, int alto)
        {
            Area = new Rectangle(x, y, ancho, alto);
        }
    }
}
