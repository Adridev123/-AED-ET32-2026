﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace MiPrimerJuego
{
    public class Game1 : Game
    {

        private Texture2D personaje;
        private Vector2 posicion;
        private float velocidad = 200f;
        private List<Obstaculo> obstaculos = new List<Obstaculo>();
        private List<Pared> paredes = new List<Pared>();
        private PilaManual historialChoques = new PilaManual(20);

        private Texture2D pixel;
        private SpriteFont fuente;
        private int vidas = 4;
        private int puntaje = 0;
        private Texture2D fondo;



        Random random = new Random();
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        KeyboardState tecladoAnterior;
        const int anchoVirtual = 1920;
        const int altoVirtual = 1080;
        const float escalaPantalla = 2f / 3f;
        Keys ultimaHorizontal;
        Keys ultimaVertical;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            _graphics.IsFullScreen = false;

            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.PreferredBackBufferHeight = 720;
            _graphics.ApplyChanges();

        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {

            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here

            personaje = Content.Load<Texture2D>("personaje");

            posicion = new Vector2(0, 0);
            fondo = Content.Load<Texture2D>("fondo");
            fuente = Content.Load<SpriteFont>("Arial");
            pixel = new Texture2D(GraphicsDevice, 1, 1);
            pixel.SetData(new[] { Color.White });

            obstaculos.Add(new Obstaculo(random.Next(1900), random.Next(1080), 50, 50));
            obstaculos.Add(new Obstaculo(random.Next(1900), random.Next(1080), 50, 50));
            obstaculos.Add(new Obstaculo(random.Next(1900), random.Next(1080), 50, 50));
            obstaculos.Add(new Obstaculo(random.Next(1900), random.Next(1080), 50, 50));


/*          paredes.Add(new Pared(200, 200, 100, 30));
            paredes.Add(new Pared(400, 300, 30, 150));*/
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            KeyboardState teclado = Keyboard.GetState();

            float tiempo = (float)gameTime
                .ElapsedGameTime.TotalSeconds;

            if (teclado.IsKeyDown(Keys.A) && tecladoAnterior.IsKeyUp(Keys.A))
                ultimaHorizontal = Keys.A;

            if (teclado.IsKeyDown(Keys.D) && tecladoAnterior.IsKeyUp(Keys.D))
                ultimaHorizontal = Keys.D;

            if (teclado.IsKeyDown(Keys.W) && tecladoAnterior.IsKeyUp(Keys.W))
                ultimaVertical = Keys.W;

            if (teclado.IsKeyDown(Keys.S) && tecladoAnterior.IsKeyUp(Keys.S))
                ultimaVertical = Keys.S;

            if (teclado.IsKeyDown(Keys.A) && !teclado.IsKeyDown(Keys.D))
                posicion.X -= velocidad * (float)gameTime.ElapsedGameTime.TotalSeconds;

            else if (teclado.IsKeyDown(Keys.D) && !teclado.IsKeyDown(Keys.A))
                posicion.X += velocidad * (float)gameTime.ElapsedGameTime.TotalSeconds;

            else if (teclado.IsKeyDown(Keys.A) && teclado.IsKeyDown(Keys.D))
            {
                if (ultimaHorizontal == Keys.A)
                    posicion.X -= velocidad * (float)gameTime.ElapsedGameTime.TotalSeconds;

                else if (ultimaHorizontal == Keys.D)
                    posicion.X += velocidad * (float)gameTime.ElapsedGameTime.TotalSeconds;
            }


            if (teclado.IsKeyDown(Keys.W) && !teclado.IsKeyDown(Keys.S))
                posicion.Y -= velocidad * (float)gameTime.ElapsedGameTime.TotalSeconds;

            else if (teclado.IsKeyDown(Keys.S) && !teclado.IsKeyDown(Keys.W))
                posicion.Y += velocidad * (float)gameTime.ElapsedGameTime.TotalSeconds;

            else if (teclado.IsKeyDown(Keys.W) && teclado.IsKeyDown(Keys.S))
            {
                if (ultimaVertical == Keys.W)
                    posicion.Y -= velocidad * (float)gameTime.ElapsedGameTime.TotalSeconds;

                else if (ultimaVertical == Keys.S)
                    posicion.Y += velocidad * (float)gameTime.ElapsedGameTime.TotalSeconds;
            }

            if (teclado.IsKeyDown(Keys.F11) && tecladoAnterior.IsKeyUp(Keys.F11))
            {
                _graphics.IsFullScreen = !_graphics.IsFullScreen;
                if (_graphics.IsFullScreen)
                {
                    _graphics.PreferredBackBufferWidth = 1920;
                    _graphics.PreferredBackBufferHeight = 1080;
                }
                else
                {
                    _graphics.PreferredBackBufferWidth = 1280;
                    _graphics.PreferredBackBufferHeight = 720;
                }

                _graphics.ApplyChanges();
            }

            if (teclado.IsKeyDown(Keys.LeftShift))
            {
                velocidad = 400f;
            }
            else
            {
                velocidad = 200f;
            }

            if (teclado.IsKeyDown(Keys.Space) && tecladoAnterior.IsKeyUp(Keys.Space))
            {
                for (int i = 0; i < obstaculos.Count; i++)
                {
                    Obstaculo obstaculo = obstaculos[i];
                    if (!obstaculo.Activo)
                        continue;
                    else
                    {
                        obstaculo.Activo = false;
                    }
                }
                obstaculos.Add(new Obstaculo(random.Next(1900), random.Next(1080), 50, 50));
                obstaculos.Add(new Obstaculo(random.Next(1900), random.Next(1080), 50, 50));
                obstaculos.Add(new Obstaculo(random.Next(1900), random.Next(1080), 50, 50));
                obstaculos.Add(new Obstaculo(random.Next(1900), random.Next(1080), 50, 50));
            }

            posicion.X = MathHelper.Clamp(posicion.X, 0, anchoVirtual - (personaje.Width * 3) / 10);
            posicion.Y = MathHelper.Clamp(posicion.Y, 0, altoVirtual - (personaje.Height * 3) / 10);
            tecladoAnterior = teclado;

            Rectangle areaPersonaje = new Rectangle(
                (int)posicion.X,
                (int)posicion.Y,
                ((personaje.Width * 3) - 20) / 10,
                ((personaje.Height * 3) - 20) / 10
            );

            for (int i = 0; i < obstaculos.Count; i++)
            {
                Obstaculo obstaculo = obstaculos[i];

                if (!obstaculo.Activo)
                    continue;

                if (areaPersonaje.Intersects(obstaculo.Area))
                {
                    vidas--;

                    historialChoques.Push(obstaculo.Area);

                    obstaculo.Activo = false;
                }
            }
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            _spriteBatch.Begin(transformMatrix: Matrix.CreateScale(escalaPantalla));

            _spriteBatch.Draw(
                fondo,
                new Rectangle(0, 0, 1920, 1080),
                Color.White
            );

            _spriteBatch.Draw(
                personaje,
                posicion,
                null,
                Color.White,
                0f,
                Vector2.Zero,
                0.3f,
                SpriteEffects.None,
                0f
            );

            // Dibujar vidas
            _spriteBatch.DrawString(
                fuente,
                "Vidas: " + vidas,
                new Vector2(10, 10),
                Color.White
            );

            // Dibujar puntaje
            _spriteBatch.DrawString(
                fuente,
                "Puntaje: " + puntaje,
                new Vector2(10, 70),
                Color.Yellow
            );
            // Dibujar obstáculos activos
            foreach (Obstaculo obstaculo in obstaculos)
            {
                if (obstaculo.Activo)
                {
                    _spriteBatch.Draw(
                        pixel,
                        obstaculo.Area,
                        Color.Red
                    );
                }
            }

            // Dibujar vidas
            _spriteBatch.DrawString(
                fuente,
                "Vidas: " + vidas,
                new Vector2(10, 10),
                Color.White
            );

            // Mostrar registros de la pila
            _spriteBatch.DrawString(
                fuente,
                "Choques registrados: " + historialChoques.Cantidad,
                new Vector2(10, 40),
                Color.Yellow
            );
            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
